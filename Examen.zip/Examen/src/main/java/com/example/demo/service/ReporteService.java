package com.example.demo.service;

import com.example.demo.entitty.Producto;
import com.example.demo.repository.ProductoRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ReporteService {

    @Autowired
    private ProductoRepository productoRepository;

    public ByteArrayResource generarReportePDF() throws DocumentException, IOException {
        List<Producto> productos = productoRepository.findAll();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(new Paragraph("Reporte de Productos"));

            for (Producto producto : productos) {
                document.add(new Paragraph("ID: " + producto.getId()));
                document.add(new Paragraph("Nombre: " + producto.getNombre()));
                document.add(new Paragraph("Categoría: " + producto.getCategoria()));
                document.add(new Paragraph("Cantidad: " + producto.getCantidad()));
                document.add(new Paragraph("Precio: " + producto.getPrecio()));
                document.add(new Paragraph("Ubicación: " + producto.getUbicacion()));
                document.add(new Paragraph("-------------------------------------------------"));
            }

            document.close();
            return new ByteArrayResource(out.toByteArray());
        }
    }
}
