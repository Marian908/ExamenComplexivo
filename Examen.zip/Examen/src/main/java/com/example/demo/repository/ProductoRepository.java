package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entitty.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    // Custom query methods if needed
}
